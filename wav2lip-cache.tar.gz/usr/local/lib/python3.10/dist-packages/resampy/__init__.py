#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''Sinc interpolation resampling'''

from .version import version as __version__
from . import filters
from .core import *
